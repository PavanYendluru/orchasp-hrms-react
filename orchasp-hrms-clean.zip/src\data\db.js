import { generateAnnouncements,
  generateAssets,
  generateAttendance,
  generateDepartments,
  generateEmployees,
  generateHolidays,
  generateLeaves,
  generateNotifications,
  generatePayroll,
  generateProjects,
  generateTasks,
 } from './generators';

const departments = generateDepartments(10);
const employees = generateEmployees(60, departments);
const attendance = generateAttendance(employees, 30);
const leaves = generateLeaves(employees, 60);
const payroll = generatePayroll(employees);
const assets = generateAssets(60);
const projects = generateProjects(employees, 12);
const tasks = generateTasks(employees, projects, 50);
const notifications = generateNotifications(20);
const announcements = generateAnnouncements(6);
const holidays = generateHolidays(8);

export const db = {
  departments,
  employees,
  attendance,
  leaves,
  payroll,
  assets,
  projects,
  tasks,
  notifications,
  announcements,
  holidays,
};

